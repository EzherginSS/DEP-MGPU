{{ config(materialized='table') }}

SELECT
    p.product_name,
    p.category,
    p.subcategory,
    SUM(f.quantity) as total_quantity_sold,
    SUM(f.sales) as total_sales,
    COUNT(DISTINCT f.order_id) as number_of_orders
FROM {{ ref('sales_fact') }} AS f
LEFT JOIN {{ ref('product_dim') }} AS p ON f.product_id_key = p.product_id_key
GROUP BY p.product_name, p.category, p.subcategory
ORDER BY total_quantity_sold DESC
LIMIT 10