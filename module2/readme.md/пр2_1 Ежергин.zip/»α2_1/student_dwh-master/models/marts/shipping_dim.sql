{{ config(materialized='table') }}

SELECT
    ROW_NUMBER() OVER (ORDER BY ship_mode) as shipping_id,
    ship_mode
FROM {{ ref('stg_orders') }}
GROUP BY ship_mode