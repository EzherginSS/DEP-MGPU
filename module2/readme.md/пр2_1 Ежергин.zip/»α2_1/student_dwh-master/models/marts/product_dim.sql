{{ config(materialized='table') }}

SELECT
    ROW_NUMBER() OVER (ORDER BY product_id) as product_id_key,
    product_id,
    product_name,
    category,
    subcategory
FROM {{ ref('stg_orders') }}
GROUP BY product_id, product_name, category, subcategory