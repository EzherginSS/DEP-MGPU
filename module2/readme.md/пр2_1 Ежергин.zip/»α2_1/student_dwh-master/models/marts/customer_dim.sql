{{ config(materialized='table') }}

SELECT
    ROW_NUMBER() OVER (ORDER BY customer_id) as customer_id_key,
    customer_id,
    customer_name,
    segment
FROM {{ ref('stg_orders') }}
GROUP BY customer_id, customer_name, segment