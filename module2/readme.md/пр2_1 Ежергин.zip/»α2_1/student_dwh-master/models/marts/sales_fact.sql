{{ config(materialized='table') }}

WITH orders AS (
    SELECT 
        o.*,
        c.customer_id_key,
        p.product_id_key,
        g.geo_id,
        s.shipping_id,
        cd.date_key
    FROM {{ ref('stg_orders') }} o
    LEFT JOIN {{ ref('customer_dim') }} c ON o.customer_id = c.customer_id
    LEFT JOIN {{ ref('product_dim') }} p ON o.product_id = p.product_id
    LEFT JOIN {{ ref('geo_dim') }} g ON o.state = g.state AND o.city = g.city AND o.postal_code = g.postal_code
    LEFT JOIN {{ ref('shipping_dim') }} s ON o.ship_mode = s.ship_mode
    LEFT JOIN {{ ref('calendar_dim') }} cd ON o.order_date = cd.order_date
)
SELECT
    order_id,
    customer_id_key,
    product_id_key,
    geo_id,
    shipping_id,
    date_key,
    sales,
    quantity,
    discount,
    profit
FROM orders