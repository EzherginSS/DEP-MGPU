{{ config(materialized='table') }}

SELECT
    ROW_NUMBER() OVER (ORDER BY state, city, postal_code) as geo_id,
    country,
    city,
    state,
    postal_code,
    region
FROM {{ ref('stg_orders') }}
GROUP BY country, city, state, postal_code, region