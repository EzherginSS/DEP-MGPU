{{ config(materialized='table') }}

WITH date_series AS (
    SELECT 
        generate_series(
            (SELECT MIN(order_date) FROM {{ ref('stg_orders') }}),
            (SELECT MAX(order_date) FROM {{ ref('stg_orders') }}),
            '1 day'::interval
        ) as date
)
SELECT
    ROW_NUMBER() OVER (ORDER BY date) as date_key,
    date as order_date,
    EXTRACT(YEAR FROM date) as year,
    EXTRACT(QUARTER FROM date) as quarter,
    EXTRACT(MONTH FROM date) as month,
    EXTRACT(DAY FROM date) as day,
    TO_CHAR(date, 'Day') as day_name
FROM date_series