# МГПУ
# Проект: student_dwh
# Выполнил(а): [Ежергин С.С.]
# Группа: [251м]

## Архитектура DWH
### Скриншот графа зависимостей
![lineage](snapshots/lineage.png)

## Описание проекта

Проект реализует хранилище данных для анализа продаж компании Superstore с использованием dbt (data build tool).

## Описание структуры

### models/ - Модели данных
- **marts/** - Витрины данных (таблицы измерений и фактов)
  - `calendar_dim.sql` - Измерение дат
  - `customer_dim.sql` - Измерение клиентов  
  - `geo_dim.sql` - Географическое измерение
  - `product_dim.sql` - Продуктовое измерение
  - `sales_fact.sql` - Фактовая таблица продаж
  - `shipping_dim.sql` - Измерение способов доставки
  - `mart_top_products_by_quantity.sql` - Индивидуальная модель (топ-10 товаров)

- **staging/** - Staging-слой
  - `stg_orders.sql` - Очищенные и подготовленные данные заказов
  - `sources.yml` - Описание источников данных

- **marts/schema.yml** - Тесты и документация для моделей

### macros/ - Макросы
- `get_custom_schema.sql` - Макрос для генерации имен схем

### screenshots/ - Скриншоты для отчета
- `dbt_run.png` - Выполнение dbt run
- `dbt_test.png` - Выполнение dbt test  
- `data_mart.png` - Данные из индивидуальной модели

### Конфигурационные файлы
- `.gitignore` - Исключаемые файлы для Git
- `dbt_project.yml` - Основная конфигурация dbt-проекта
- `requirements.txt` - Зависимости проекта
- `README.md` - Документация проекта

## Ключевые фрагменты кода

### Модель stg_orders.sql
```sql
{{ config(materialized='view') }}

SELECT 
    "Row ID" as row_id,
    "Order ID" as order_id,
    "Order Date" as order_date,
    "Ship Date" as ship_date,
    "Ship Mode" as ship_mode,
    "Customer ID" as customer_id,
    "Customer Name" as customer_name,
    "Segment" as segment,
    "Country" as country,
    "City" as city,
    "State" as state,
    "Postal Code" as postal_code,
    "Region" as region,
    "Product ID" as product_id,
    "Category" as category,
    "Sub-Category" as subcategory,
    "Product Name" as product_name,
    "Sales" as sales,
    "Quantity" as quantity,
    "Discount" as discount,
    "Profit" as profit
FROM {{ source('staging', 'orders') }}
```

### Модель sales_fact.sql
```sql
{{ config(materialized='table') }}

WITH orders AS (
    SELECT 
        o.*,
        c.customer_id_key,
        p.product_id_key,
        g.geo_id,
        s.shipping_id,
        cd.date_key
    FROM {{ ref('stg_orders') }} o
    LEFT JOIN {{ ref('customer_dim') }} c ON o.customer_id = c.customer_id
    LEFT JOIN {{ ref('product_dim') }} p ON o.product_id = p.product_id
    LEFT JOIN {{ ref('geo_dim') }} g ON o.state = g.state AND o.city = g.city AND o.postal_code = g.postal_code
    LEFT JOIN {{ ref('shipping_dim') }} s ON o.ship_mode = s.ship_mode
    LEFT JOIN {{ ref('calendar_dim') }} cd ON o.order_date = cd.order_date
)
SELECT
    order_id,
    customer_id_key,
    product_id_key,
    geo_id,
    shipping_id,
    date_key,
    sales,
    quantity,
    discount,
    profit
FROM orders
```

### Индивидуальная модель mart_top_products_by_quantity.sql
```sql
{{ config(materialized='table') }}

SELECT
    p.product_name,
    p.category,
    p.subcategory,
    SUM(f.quantity) as total_quantity_sold,
    SUM(f.sales) as total_sales,
    COUNT(DISTINCT f.order_id) as number_of_orders
FROM {{ ref('sales_fact') }} AS f
LEFT JOIN {{ ref('product_dim') }} AS p ON f.product_id_key = p.product_id_key
GROUP BY p.product_name, p.category, p.subcategory
ORDER BY total_quantity_sold DESC
LIMIT 10
```

### Файл schema.yml
```sql
version: 2

models:
  - name: customer_dim
    columns:
      - name: customer_id_key
        tests:
          - unique
          - not_null
      - name: customer_id
        tests:
          - not_null

  - name: product_dim
    columns:
      - name: product_id_key
        tests:
          - unique
          - not_null

  - name: geo_dim
    columns:
      - name: geo_id
        tests:
          - unique
          - not_null

  - name: shipping_dim
    columns:
      - name: shipping_id
        tests:
          - unique
          - not_null

  - name: calendar_dim
    columns:
      - name: date_key
        tests:
          - unique
          - not_null

  - name: sales_fact
    columns:
      - name: order_id
        tests:
          - not_null
      - name: customer_id_key
        tests:
          - not_null
          - relationships:
              to: ref('customer_dim')
              field: customer_id_key
      - name: product_id_key
        tests:
          - not_null
          - relationships:
              to: ref('product_dim')
              field: product_id_key
      - name: geo_id
        tests:
          - not_null
          - relationships:
              to: ref('geo_dim')
              field: geo_id
  - name: mart_top_products_by_quantity
    description: "Топ-10 самых продаваемых товаров по количеству"
    columns:
      - name: product_name
        tests:
          - not_null
      - name: total_quantity_sold
        tests:
          - not_null
```

## Результаты

### Скриншот выполнения dbt run
![dbt_run](snapshots/dbt_run.PNG)

*Команда dbt run успешно выполнила все 8 моделей*


### Скриншот выполнения dbt test
![dbt_test](snapshots/dbt_test.PNG)  

*Результаты тестирования: все тесты пройдены успешно*


### Скриншот данных из mart_top_products_by_quantity
![data_mart](snapshots/data_mart.PNG)

*Топ-10 самых продаваемых товаров по количеству*


## Выводы

Dbt предоставляет следующие преимущества по сравнению с ручным написанием DDL/DML скриптов:

1. **Автоматизация документации** - dbt автоматически генерирует документацию и граф зависимостей
2. **Тестирование данных** - встроенные тесты для проверки качества данных
3. **Версионность** - возможность отслеживать изменения моделей
4. **Повторное использование** - макросы и ссылки между моделями
5. **Стандартизация** - единый подход к трансформации данных
6. **Линейность зависимостей** - автоматическое определение порядка выполнения моделей
